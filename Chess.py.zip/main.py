# Chess Pseudo Code Version
# By Aiyan Alam

class chess board
  method intialize
    intilize board with square image
    board will have 8 rows and 8 columns
    initialize squares with image
    board will consist of 32 white square and 32 black squares
    black square starts on top left corner. white square starts right after the black square. use the pattern of white square and then black square
    if one row runs out of space, go to the next row
  method set pieces
    intialize pieces with image, one for eac piece
    set each piece onto the board. the queen's color should match what color the square
    the order of the white pieces are: rook, knight, bishop, queen, king, bishop, knight, rook. the order of the black pieces are: rook, knight, bishop, king, queen, bishop, knight, rook.
    the row above will have all the pawns. there should 8 pawns
class pawn:
  method intialize
    intialize pawn with image
    player selects white or black
    place = ranging from left side to right side
    duplicate 8 times in a row
  method move
    when prompted, move two spaces to the front if they are in the starting position
  method take over
    if one piece is one space diagonal to the pawn, place pawn in the piece's spot and remove the other piece
    if another piece takes over the pawn, remove the pawn from the screen.
  method turn into another piece
    if pawn reaches the end of the board, give user fouroptions to turn the pawn into. They could turn it into a rook, knight, bishop or queen
class rook:
  method initialize
    initialize rook with image
    player selects the same color they chose for pawn
    place = bottom left side and bottom right side
  method move
    when prompted, move as many spaces as possible up, down, left, or right
  method take over
    if another piece is in front of the rook, place rook in the piece's place and take away the other piece.
    if another piece takes over the rook, remove the rook from the screen
class knight:
  method initialize
    initialize knight with image
    player selects the same color they chose for the other pieces. do not let the player choose different colors, once they chose one color.
    place = between the rook and the bishop on each side
  method move
    when prompted, move two spaces up and then one space to the left or right. you may also move two spaces left or right and then move one space up or down. do not move to a space that is occupied by another piece
  method take over
    if another piece is in front of the rook, place rook in the piece's place and take away the other piece.
    if another piece takes over the rook, remove the rook from the screen
class bishop:
  method initialize
    initialize bishop with image
    player is given the color bishop that they have chose for the other pieces
    place = between the queen and the knight on each side. one bishop must be on a white square and anoter must be on a black square
  method move
    when prompted, move diagonally on the same color squares
  method take over
    if another piece is in front of the rook, place rook in the piece's place and take away the other piece.
    if another piece takes over the rook, remove the rook from the screen
class queen:
  method initialize
    initialize queen with image
    player is given the color they chose for their other pieces
    place = between the king and bishop
  method move
    when prompted, move in any way and as many spaces as you want. make sure to move any obstructing pieces
  method take over
    if another piece is in front of the rook, place rook in the piece's place and take away the other piece.
    if another piece takes over the rook, remove the rook from the screen
class king:
  method initialize
    intialize king with image
    player i given the color they chose for their other pieces
    place = between queen and bishop
  method move
    when prompted, move to any space that is one space in distance away from the starting position. if the king is in check, move to a safe space. do not allow the player to move to a space that may threaten the king again.
  method castle:
    if there is no bishop and knight between the rook and the king, the rook has not been moved yet, and the rook is four spaces away from the king, you may castle. move the king two spaces toward the rook and then move the rook right next to king that is not in it's starting position. do not castle if the king is in check
  method take over
    if another piece is in front of the rook, place rook in the piece's place and take away the other piece.
  method check
    if a piece from the opposition is trying to take over the king, show the word "CHECK". the king must either move away to a safe spot to where it can't be checked or they must use another piece to block the attack.
  method checkmate
    if the king cannot safely move out of the spot it is sitting in check from and if there are no pieces that can block the attack, show the word, "CHECKMATE! GAME OVER" Underneath, show the button, "PLAY AGAIN"